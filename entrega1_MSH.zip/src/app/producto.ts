export class Producto {
  id!: number;
  nombre!: string;
  descripcion!: string;
  precio!: number;
  categoria!: string;
  valoracionMedia!: number;
}
