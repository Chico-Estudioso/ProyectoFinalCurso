import { Component } from '@angular/core';

@Component({
  selector: 'app-valoraciones-cli',
  templateUrl: './valoraciones-cli.component.html',
  styleUrls: ['./valoraciones-cli.component.css']
})
export class ValoracionesCliComponent {

}
