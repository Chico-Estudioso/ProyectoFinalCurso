export class Valoracion {
  id!: number;
  cli!: string;
  prod!: string;
  descripcion!: string;
  fecha!: string;
  puntuacion!: number;
}
